from .engine import run


def main():
    run()
