# Primitive DB

A minimal CLI to manage tables and persist metadata to db_meta.json.

**Управление таблицами**
- create_table <имя_таблицы> <столбец:тип> ...: создать таблицу. Автоматически добавляется ID:int.
- list_tables: показать список всех таблиц.
- drop_table <имя_таблицы>: удалить таблицу.
- help: показать справку.
- exit: выйти.

Поддерживаемые типы: int, str, bool.

## Пример использования

>>> database
>>>Введите команду: create_table users name:str age:int is_active:bool
Таблица "users" успешно создана со столбцами: ID:int, name:str, age:int, is_active:bool

>>>Введите команду: list_tables
- users

>>>Введите команду: drop_table users
Таблица "users" успешно удалена.

## Установка и запуск

python -m pip install --upgrade build
python -m build
pip install dist/primitive_db-0.1.0-py3-none-any.whl

database

После установки команда database запускает интерфейс.

## Аскинема
Запишите демонстрацию установки, запуска и операций и встроите ссылку здесь.

## CRUD-операции
- insert into <имя_таблицы> values ("<значение1>", ...): добавить запись (без ID).
- select from <имя_таблицы> [where <столбец> = <значение>]: вывести записи, красиво с PrettyTable.
- update <имя_таблицы> set <столбец> = <значение> where <столбец> = <значение>: обновить записи.
- delete from <имя_таблицы> where <столбец> = <значение>: удалить записи.
- info <имя_таблицы>: показать схему и количество записей.

### Демонстрация CRUD
>>>Введите команду: insert into users values ("Sergei", 28, true)
Запись с ID=1 успешно добавлена в таблицу "users".

>>>Введите команду: select from users where age = 28
+----+--------+-----+-----------+
| ID |  name  | age | is_active |
+----+--------+-----+-----------+
| 1  | Sergei | 28  |    True   |
+----+--------+-----+-----------+

>>>Введите команду: update users set age = 29 where name = "Sergei"
Запись с ID=1 в таблице "users" успешно обновлена.

>>>Введите команду: delete from users where ID = 1
Запись с ID=1 успешно удалена из таблицы "users".

>>>Введите команду: info users
Таблица: users
Столбцы: ID:int, name:str, age:int, is_active:bool
Количество записей: 0

## Декораторы и улучшения
- Обработка ошибок: декоратор `handle_db_errors` централизует try/except и выводит понятные сообщения.
- Подтверждение действий: `confirm_action("удаление таблицы")` и `confirm_action("удаление записей")` запрашивают подтверждение перед опасными операциями.
- Логирование времени: `log_time` печатает длительность выполнения для операций `insert` и `select`.
- Кэширование выборок: замыкание `create_cacher()` кэширует результаты `select` по условию.

Пример подтверждения:
Вы уверены, что хотите выполнить "удаление таблицы"? [y/n]:
